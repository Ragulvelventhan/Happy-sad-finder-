# Happy or Sad Mood Guesser
# Beginner Python project for the AIXcelerate selection task

train_data = [
    ("I got full marks in the test today!", "Happy"),
    ("We won the college cricket match", "Happy"),
    ("My friends planned a surprise party for me", "Happy"),
    ("The food in the canteen was really tasty", "Happy"),
    ("I am so excited for the weekend trip", "Happy"),
    ("Our project got selected for the exhibition", "Happy"),
    ("I finally learned how to ride a bicycle", "Happy"),
    ("Mom made my favourite sweets today", "Happy"),
    ("I lost my phone on the bus", "Sad"),
    ("I failed in the mathematics exam", "Sad"),
    ("My best friend is moving to another city", "Sad"),
    ("It rained and our picnic was cancelled", "Sad"),
    ("I missed the last bus and felt very upset", "Sad"),
    ("My laptop stopped working before the submission", "Sad"),
    ("I felt lonely during the long holidays", "Sad")
]


# Count how many Happy and Sad examples are in the data.
def count_moods(data):
    happy_count = 0
    sad_count = 0

    for sentence, mood in data:
        if mood == "Happy":
            happy_count += 1
        elif mood == "Sad":
            sad_count += 1

    return happy_count, sad_count


# IMPORTANT: Replace these example words so each list contains exactly
# the number of words required by the last digit of your roll number.
# If your roll number ends in 0, use 10 words in each list.
happy_words = ["won", "excited", "surprise"]
sad_words = ["lost", "failed", "upset"]


def guess_mood(sentence):
    # Convert to lowercase so capital letters do not affect matching.
    sentence = sentence.lower()

    # Remove common punctuation.
    for mark in ".,!?;:'\"()[]{}":
        sentence = sentence.replace(mark, "")

    happy_score = 0
    sad_score = 0

    words = sentence.split()

    # Give one point for each matching clue word.
    for word in words:
        if word in happy_words:
            happy_score += 1
        if word in sad_words:
            sad_score += 1

    if happy_score > sad_score:
        return "Happy"
    else:
        # Tie rule: choose Sad when both scores are equal.
        return "Sad"


practice_data = [
    ("I won a medal in the sports meet", "Happy"),
    ("I lost my notebook before the exam", "Sad"),
    ("My friends gave me a lovely surprise", "Happy"),
    ("The train was late and I felt upset", "Sad"),
    ("Today was a great day", "Happy")
]


if __name__ == "__main__":
    print("Happy and Sad sentence count:", count_moods(train_data))
    print("\nPractice results:")

    correct = 0

    for sentence, actual_mood in practice_data:
        predicted_mood = guess_mood(sentence)
        print(sentence, "->", predicted_mood)

        if predicted_mood == actual_mood:
            correct += 1

    accuracy = (correct / len(practice_data)) * 100
    print("\nAccuracy:", accuracy, "%")
