# Happy or Sad Mood Guesser

A small beginner-level Python project that guesses whether a sentence is **Happy** or **Sad** by checking for clue words.

## Files
- `main.py` – contains the sample data, functions and practice test.

## How to run
1. Open `main.py` in Python, VS Code, IDLE, or an online Python compiler.
2. Run the file.
3. Read the mood count, practice predictions and accuracy printed on the screen.

## How it works
- `count_moods(data)` counts the Happy and Sad examples using a loop.
- `happy_words` and `sad_words` contain clue words.
- `guess_mood(sentence)` converts the sentence to lowercase, removes common punctuation, and checks its words against the clue lists.
- The mood with more matching clue words is returned.
- If both scores are equal, the program chooses **Sad**. This is the tie rule used in this version.

## Important: personalise the clue-word lists
The AIXcelerate instructions require each clue-word list to contain exactly N words, where N is the last digit of your roll number. If the last digit is 0, use N = 10.

The lists currently contain **3 words each as an example**. Before submitting, change them to the required number of words and test the program again.

## Level 3: Testing
The program runs the five practice sentences and calculates accuracy automatically. After running your final version, write the accuracy shown by your own run here.

Accuracy on the 5 practice sentences: **80% with the example three-word lists**.

1. Which sentence went wrong (or was closest to going wrong), and why?

   Example reflection to rewrite in your own words: “Today was a great day” was predicted as Sad because none of its words matched my clue lists, so both scores were zero and the tie rule selected Sad.

2. One change that would make my program better:

   Example idea to explain in your own words: I could choose more useful clue words and test the program with more sentences that it has not seen before.

## Learning questions

1. Total score of "good party today" and its mood: **+3, Happy**.
2. Total score of "bad exam day" and its mood: **-3, Sad**.
3. Why did "exam" get a score of 0, and is that good or bad?

   It appeared once in a Happy sentence and once in a Sad sentence, so the two counts cancel each other. This can be useful because the word does not favour either mood in those examples.

4. Why is "not good" labelled Happy by this method, and how could it be fixed?

   The method gives “good” a positive score but does not understand that “not” changes its meaning. A simple improvement is to check for negation words such as “not” before a positive clue word and reverse or reduce that word's score.

## AI declaration

Complete this honestly before submitting. If you used ChatGPT, select **yes** and describe what you asked it. For example:

“I used an AI tool: yes. I asked ChatGPT to explain the project instructions and help me understand a beginner-level Python structure. I reviewed the code and am learning what each part does.”

Edit this statement so it accurately describes how you used AI.

## Reflection

Write this in your own words after you have run and understood the program:
- What was hardest?
- What did you learn that you did not know before?

## Before submitting
- [ ] Change the clue-word lists to match the last digit of your roll number.
- [ ] Run the final `main.py` and check its output.
- [ ] Complete the README answers in your own words.
- [ ] Add a genuine screenshot of your program running as `screenshot.png`.
- [ ] Upload `main.py`, `README.md`, and `screenshot.png` to a **public** GitHub repository.
- [ ] Make at least 3 commits at different stages of your work.
- [ ] Submit the repository link in Form 1 before the deadline.

**Important:** This ZIP is a starter project. It does not contain a screenshot or GitHub commit history; those must be created by you.
